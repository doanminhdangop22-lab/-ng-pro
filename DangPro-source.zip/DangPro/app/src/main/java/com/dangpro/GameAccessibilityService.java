package com.dangpro;

import android.accessibilityservice.AccessibilityService;
import android.graphics.*;
import android.media.projection.MediaProjection;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

/**
 * Accessibility service — chạy nền, không inject vào FF.
 * Dùng AccessibilityEvent để detect khi FF active.
 * Kết hợp với MediaProjection (screen capture) để phân tích frame.
 *
 * NOTE: ESP data thật cần screen capture + image processing.
 * Service này handle lifecycle và feed data vào OverlayView.
 */
public class GameAccessibilityService extends AccessibilityService {

    private static final String FF_PACKAGE = "com.dts.freefireth";
    private boolean ffActive = false;

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null) return;

        CharSequence pkg = event.getPackageName();
        if (pkg == null) return;

        if (pkg.toString().equals(FF_PACKAGE)) {
            ffActive = true;
            // FF đang active — overlay có thể vẽ
        } else {
            ffActive = false;
            // App khác — clear entities
            OverlayView.espEnable = false;
        }
    }

    @Override
    public void onInterrupt() {
        ffActive = false;
    }

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        // Service connect thành công
    }

    public boolean isFFActive() { return ffActive; }
}
