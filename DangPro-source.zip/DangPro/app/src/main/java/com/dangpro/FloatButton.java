package com.dangpro;

import android.content.Context;
import android.graphics.*;
import android.view.*;

public class FloatButton extends View {

    public interface DoubleTapListener { void onDoubleTap(); }
    private DoubleTapListener listener;

    private Paint  paintBg, paintText, paintBorder;
    private long   lastTap = 0;
    private static final long DBL_TAP_MS = 350;

    public FloatButton(Context ctx) {
        super(ctx);

        paintBg = new Paint(Paint.ANTI_ALIAS_FLAG);
        paintBg.setColor(Color.argb(220, 15, 15, 15));
        paintBg.setStyle(Paint.Style.FILL);

        paintBorder = new Paint(Paint.ANTI_ALIAS_FLAG);
        paintBorder.setColor(Color.argb(255, 255, 100, 0));
        paintBorder.setStyle(Paint.Style.STROKE);
        paintBorder.setStrokeWidth(4f);

        paintText = new Paint(Paint.ANTI_ALIAS_FLAG);
        paintText.setColor(Color.argb(255, 255, 140, 0));
        paintText.setTextSize(22f);
        paintText.setTextAlign(Paint.Align.CENTER);
        paintText.setTypeface(Typeface.create(Typeface.DEFAULT_BOLD, Typeface.BOLD));
    }

    public void setOnDoubleTapListener(DoubleTapListener l) { this.listener = l; }

    @Override
    protected void onDraw(Canvas canvas) {
        float cx = getWidth() / 2f;
        float cy = getHeight() / 2f;
        float r  = Math.min(cx, cy) - 4f;

        // Nền tròn
        canvas.drawCircle(cx, cy, r, paintBg);
        // Viền cam
        canvas.drawCircle(cx, cy, r, paintBorder);
        // Chữ "Đăng\npro"
        canvas.drawText("Đăng", cx, cy - 8f, paintText);
        canvas.drawText("pro",  cx, cy + 18f, paintText);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (e.getAction() == MotionEvent.ACTION_DOWN) {
            long now = System.currentTimeMillis();
            if (now - lastTap < DBL_TAP_MS) {
                if (listener != null) listener.onDoubleTap();
                lastTap = 0;
            } else {
                lastTap = now;
            }
            return true;
        }
        return super.onTouchEvent(e);
    }
}
