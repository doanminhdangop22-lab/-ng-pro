package com.dangpro;

import android.app.*;
import android.content.Context;
import android.content.Intent;
import android.graphics.*;
import android.os.*;
import android.view.*;
import android.view.accessibility.AccessibilityEvent;
import android.widget.*;

public class OverlayService extends Service {

    private WindowManager   wm;
    private OverlayView     overlayView;
    private FloatButton     floatBtn;

    @Override
    public void onCreate() {
        super.onCreate();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        createNotificationChannel();
        startForeground(1, buildNotification());
        spawnFloatButton();
        spawnOverlay();
    }

    // ── FLOATING BUTTON TRÒN GÓC TRÊN TRÁI ──────────────────────────────
    private void spawnFloatButton() {
        floatBtn = new FloatButton(this);
        floatBtn.setOnDoubleTapListener(() -> {
            overlayView.toggleMenu();
        });

        WindowManager.LayoutParams p = new WindowManager.LayoutParams(
            150, 150,
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT);
        p.gravity = Gravity.TOP | Gravity.START;
        p.x = 20;
        p.y = 20;
        wm.addView(floatBtn, p);
    }

    // ── OVERLAY ESP + MENU ───────────────────────────────────────────────
    private void spawnOverlay() {
        overlayView = new OverlayView(this);

        WindowManager.LayoutParams p = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                | WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT);
        p.gravity = Gravity.TOP | Gravity.START;
        wm.addView(overlayView, p);
    }

    // ── NOTIFICATION (foreground service bắt buộc) ──────────────────────
    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(
                "dangpro", "Đăng Pro", NotificationManager.IMPORTANCE_LOW);
            ch.setSound(null, null);
            ((NotificationManager) getSystemService(NOTIFICATION_SERVICE))
                .createNotificationChannel(ch);
        }
    }

    private Notification buildNotification() {
        return new Notification.Builder(this,
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ? "dangpro" : "")
            .setContentTitle("Đăng Pro")
            .setContentText("Overlay đang chạy")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .build();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (floatBtn  != null) wm.removeView(floatBtn);
        if (overlayView != null) wm.removeView(overlayView);
    }

    @Override public IBinder onBind(Intent i) { return null; }
}
