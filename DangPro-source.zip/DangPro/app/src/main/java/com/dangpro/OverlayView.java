package com.dangpro;

import android.content.Context;
import android.graphics.*;
import android.view.*;

import java.util.ArrayList;
import java.util.List;

public class OverlayView extends View {

    // ── FEATURE FLAGS ────────────────────────────────────────────────────
    public static boolean espEnable    = true;
    public static boolean espBox       = true;
    public static boolean espName      = true;
    public static boolean espHealth    = true;
    public static boolean espDistance  = true;
    public static boolean espArrow     = true;
    public static boolean aimEnable    = true;
    public static float   aimSmooth    = 0.40f;
    public static boolean speedEnable  = false;
    public static boolean antiBand     = true;

    // ── MENU STATE ───────────────────────────────────────────────────────
    private boolean menuOpen = false;
    private int     activeTab = 0; // 0=ESP 1=AIM 2=MISC
    private static final String[] TABS = {"ESP", "AIM", "MISC"};

    // ── PAINT ─────────────────────────────────────────────────────────────
    private Paint pBox, pBoxCorner, pName, pHealth, pHealthBg;
    private Paint pArrow, pDist;
    private Paint pMenuBg, pMenuBorder, pMenuTitle;
    private Paint pTabActive, pTabInactive, pTabText;
    private Paint pToggleBg, pToggleOn, pToggleText;
    private Paint pSliderBg, pSliderFill, pSliderLabel;

    // ── MOCK ESP DATA (thay bằng data thật từ AccessibilityService) ──────
    private List<EspEntity> entities = new ArrayList<>();

    // ── MENU RECTS ────────────────────────────────────────────────────────
    private RectF menuRect;
    private RectF[] tabRects = new RectF[3];
    private RectF   closeRect;

    // ── SLIDER STATE ─────────────────────────────────────────────────────
    private boolean draggingAim   = false;
    private boolean draggingSpeed = false;
    private RectF   aimSliderRect, speedSliderRect;
    private float   speedMult = 1.5f;

    public OverlayView(Context ctx) {
        super(ctx);
        initPaints();
        setLayerType(LAYER_TYPE_HARDWARE, null);

        // Tick redraw ~30fps
        postDelayed(ticker, 33);
    }

    private Runnable ticker = new Runnable() {
        @Override public void run() {
            updateEntities();
            invalidate();
            postDelayed(this, 33);
        }
    };

    // ── INIT PAINTS ──────────────────────────────────────────────────────
    private void initPaints() {
        pBox = new Paint(Paint.ANTI_ALIAS_FLAG);
        pBox.setColor(Color.argb(200, 255, 60, 60));
        pBox.setStyle(Paint.Style.STROKE);
        pBox.setStrokeWidth(2.5f);

        pBoxCorner = new Paint(pBox);
        pBoxCorner.setStrokeWidth(3.5f);
        pBoxCorner.setColor(Color.argb(255, 255, 80, 80));

        pName = new Paint(Paint.ANTI_ALIAS_FLAG);
        pName.setColor(Color.WHITE);
        pName.setTextSize(28f);
        pName.setTextAlign(Paint.Align.CENTER);
        pName.setShadowLayer(3f, 1f, 1f, Color.BLACK);

        pHealth = new Paint(Paint.ANTI_ALIAS_FLAG);
        pHealth.setStyle(Paint.Style.FILL);

        pHealthBg = new Paint(Paint.ANTI_ALIAS_FLAG);
        pHealthBg.setColor(Color.argb(160, 0, 0, 0));
        pHealthBg.setStyle(Paint.Style.FILL);

        pArrow = new Paint(Paint.ANTI_ALIAS_FLAG);
        pArrow.setColor(Color.YELLOW);
        pArrow.setTextSize(30f);
        pArrow.setTextAlign(Paint.Align.CENTER);

        pDist = new Paint(Paint.ANTI_ALIAS_FLAG);
        pDist.setColor(Color.argb(220, 200, 200, 200));
        pDist.setTextSize(22f);
        pDist.setTextAlign(Paint.Align.CENTER);
        pDist.setShadowLayer(2f, 1f, 1f, Color.BLACK);

        // Menu
        pMenuBg = new Paint(Paint.ANTI_ALIAS_FLAG);
        pMenuBg.setColor(Color.argb(235, 10, 10, 10));
        pMenuBg.setStyle(Paint.Style.FILL);

        pMenuBorder = new Paint(Paint.ANTI_ALIAS_FLAG);
        pMenuBorder.setColor(Color.argb(255, 255, 100, 0));
        pMenuBorder.setStyle(Paint.Style.STROKE);
        pMenuBorder.setStrokeWidth(3f);

        pMenuTitle = new Paint(Paint.ANTI_ALIAS_FLAG);
        pMenuTitle.setColor(Color.argb(255, 255, 120, 0));
        pMenuTitle.setTextSize(38f);
        pMenuTitle.setTypeface(Typeface.create(Typeface.DEFAULT_BOLD, Typeface.BOLD));

        pTabActive = new Paint(Paint.ANTI_ALIAS_FLAG);
        pTabActive.setColor(Color.argb(255, 255, 100, 0));
        pTabActive.setStyle(Paint.Style.FILL);

        pTabInactive = new Paint(Paint.ANTI_ALIAS_FLAG);
        pTabInactive.setColor(Color.argb(200, 50, 50, 50));
        pTabInactive.setStyle(Paint.Style.FILL);

        pTabText = new Paint(Paint.ANTI_ALIAS_FLAG);
        pTabText.setColor(Color.WHITE);
        pTabText.setTextSize(30f);
        pTabText.setTextAlign(Paint.Align.CENTER);
        pTabText.setTypeface(Typeface.create(Typeface.DEFAULT_BOLD, Typeface.BOLD));

        pToggleBg = new Paint(Paint.ANTI_ALIAS_FLAG);
        pToggleBg.setStyle(Paint.Style.FILL);

        pToggleOn = new Paint(Paint.ANTI_ALIAS_FLAG);
        pToggleOn.setColor(Color.argb(255, 255, 100, 0));
        pToggleOn.setStyle(Paint.Style.FILL);

        pToggleText = new Paint(Paint.ANTI_ALIAS_FLAG);
        pToggleText.setColor(Color.WHITE);
        pToggleText.setTextSize(28f);

        pSliderBg = new Paint(Paint.ANTI_ALIAS_FLAG);
        pSliderBg.setColor(Color.argb(180, 60, 60, 60));
        pSliderBg.setStyle(Paint.Style.FILL);

        pSliderFill = new Paint(Paint.ANTI_ALIAS_FLAG);
        pSliderFill.setColor(Color.argb(255, 255, 100, 0));
        pSliderFill.setStyle(Paint.Style.FILL);

        pSliderLabel = new Paint(Paint.ANTI_ALIAS_FLAG);
        pSliderLabel.setColor(Color.argb(220, 200, 200, 200));
        pSliderLabel.setTextSize(26f);
    }

    // ── TOGGLE MENU ──────────────────────────────────────────────────────
    public void toggleMenu() {
        menuOpen = !menuOpen;
        invalidate();
    }

    // ── MOCK: cập nhật entity từ screen capture / accessibility ──────────
    private void updateEntities() {
        // TODO: kết nối GameAccessibilityService để lấy vị trí thật
        // Hiện tại giữ entities rỗng — ESP tự động hiện khi có data
    }

    // ── DRAW ─────────────────────────────────────────────────────────────
    @Override
    protected void onDraw(Canvas canvas) {
        if (espEnable) drawESP(canvas);
        if (menuOpen)  drawMenu(canvas);
    }

    // ── ESP ──────────────────────────────────────────────────────────────
    private void drawESP(Canvas canvas) {
        for (EspEntity e : entities) {
            if (!e.visible) continue;

            float bx = e.screenX - e.boxW / 2f;
            float by = e.screenY - e.boxH;
            float bx2 = bx + e.boxW;
            float by2 = by + e.boxH;
            float cL  = e.boxW * 0.22f;

            // Corner box
            if (espBox) drawCornerBox(canvas, bx, by, bx2, by2, cL);

            // Tên
            if (espName)
                canvas.drawText(e.name, e.screenX, by - 10f, pName);

            // HP bar
            if (espHealth) drawHPBar(canvas, bx - 14f, by, by2, e.hp);

            // Khoảng cách
            if (espDistance)
                canvas.drawText((int)e.distance + "m", e.screenX, by2 + 28f, pDist);

            // Mũi tên chỉ hướng
            if (espArrow) drawArrow(canvas, e.screenX, by + e.boxH / 2f, e.angle);
        }
    }

    private void drawCornerBox(Canvas c, float x1, float y1, float x2, float y2, float cl) {
        // Top-left
        c.drawLine(x1, y1, x1 + cl, y1, pBoxCorner);
        c.drawLine(x1, y1, x1, y1 + cl, pBoxCorner);
        // Top-right
        c.drawLine(x2 - cl, y1, x2, y1, pBoxCorner);
        c.drawLine(x2, y1, x2, y1 + cl, pBoxCorner);
        // Bottom-left
        c.drawLine(x1, y2 - cl, x1, y2, pBoxCorner);
        c.drawLine(x1, y2, x1 + cl, y2, pBoxCorner);
        // Bottom-right
        c.drawLine(x2 - cl, y2, x2, y2, pBoxCorner);
        c.drawLine(x2, y2 - cl, x2, y2, pBoxCorner);
    }

    private void drawHPBar(Canvas c, float x, float top, float bot, float hp) {
        float w = 10f, h = bot - top;
        float fill = h * hp;
        // BG
        c.drawRect(x, top, x + w, bot, pHealthBg);
        // Fill - gradient đỏ → xanh
        int col = Color.rgb(
            (int)(255 * (1f - hp)),
            (int)(255 * hp), 0);
        pHealth.setColor(col);
        c.drawRect(x, bot - fill, x + w, bot, pHealth);
    }

    private void drawArrow(Canvas c, float cx, float cy, float angleDeg) {
        c.save();
        c.rotate(angleDeg, cx, cy);
        canvas_drawTriangle(c, cx, cy - 20f, 16f, pArrow);
        c.restore();
    }

    private void canvas_drawTriangle(Canvas c, float tx, float ty, float size, Paint p) {
        Path path = new Path();
        path.moveTo(tx, ty);
        path.lineTo(tx - size / 2f, ty + size);
        path.lineTo(tx + size / 2f, ty + size);
        path.close();
        p.setStyle(Paint.Style.FILL);
        c.drawPath(path, p);
    }

    // ── MENU ─────────────────────────────────────────────────────────────
    private void drawMenu(Canvas canvas) {
        int sw = getWidth(), sh = getHeight();
        float mw = sw * 0.72f, mh = sh * 0.74f;
        float mx = (sw - mw) / 2f, my = (sh - mh) / 2f;
        menuRect = new RectF(mx, my, mx + mw, my + mh);

        // Nền
        canvas.drawRoundRect(menuRect, 24f, 24f, pMenuBg);
        canvas.drawRoundRect(menuRect, 24f, 24f, pMenuBorder);

        // Title
        canvas.drawText("⚙ ĐĂNG PRO", mx + 20f, my + 52f, pMenuTitle);

        // Close button
        closeRect = new RectF(mx + mw - 70f, my + 10f, mx + mw - 10f, my + 70f);
        pToggleBg.setColor(Color.argb(200, 80, 20, 20));
        canvas.drawRoundRect(closeRect, 12f, 12f, pToggleBg);
        pTabText.setTextSize(32f);
        canvas.drawText("✕", closeRect.centerX(), closeRect.centerY() + 12f, pTabText);

        // Tabs
        float tabY = my + 72f, tabH = 58f;
        float tabW = (mw - 24f) / TABS.length;
        for (int i = 0; i < TABS.length; i++) {
            float tx = mx + 12f + tabW * i;
            tabRects[i] = new RectF(tx, tabY, tx + tabW - 4f, tabY + tabH);
            canvas.drawRoundRect(tabRects[i],
                10f, 10f, i == activeTab ? pTabActive : pTabInactive);
            canvas.drawText(TABS[i],
                tabRects[i].centerX(), tabY + tabH * 0.68f, pTabText);
        }

        // Content
        float contentY = tabY + tabH + 16f;
        float contentX = mx + 16f;
        float contentW = mw - 32f;
        switch (activeTab) {
            case 0: drawTabESP(canvas, contentX, contentY, contentW); break;
            case 1: drawTabAIM(canvas, contentX, contentY, contentW); break;
            case 2: drawTabMISC(canvas, contentX, contentY, contentW); break;
        }
    }

    private void drawTabESP(Canvas c, float x, float y, float w) {
        float lh = 68f;
        espEnable   = drawToggle(c, x, y,        w, "Bật ESP",            espEnable);
        espBox      = drawToggle(c, x, y + lh,   w, "Box vuông",          espBox);
        espName     = drawToggle(c, x, y + lh*2, w, "Tên player",         espName);
        espHealth   = drawToggle(c, x, y + lh*3, w, "Thanh HP",           espHealth);
        espDistance = drawToggle(c, x, y + lh*4, w, "Khoảng cách",        espDistance);
        espArrow    = drawToggle(c, x, y + lh*5, w, "Mũi tên hướng",      espArrow);
    }

    private void drawTabAIM(Canvas c, float x, float y, float w) {
        float lh = 68f;
        aimEnable = drawToggle(c, x, y,      w, "Bật Aim Assist", aimEnable);

        // Slider aim smooth
        float sy = y + lh + 10f;
        pSliderLabel.setColor(Color.WHITE);
        c.drawText("Độ mượt: " + Math.round(aimSmooth * 100) + "%", x, sy, pSliderLabel);
        aimSliderRect = new RectF(x, sy + 8f, x + w, sy + 36f);
        drawSlider(c, aimSliderRect, aimSmooth);

        antiBand = drawToggle(c, x, y + lh*2 + 40f, w, "Anti Band", antiBand);
    }

    private void drawTabMISC(Canvas c, float x, float y, float w) {
        float lh = 68f;
        speedEnable = drawToggle(c, x, y, w, "Speed Hack", speedEnable);

        float sy = y + lh + 10f;
        pSliderLabel.setColor(Color.WHITE);
        c.drawText("Tốc độ: " + String.format("%.1f", speedMult) + "x", x, sy, pSliderLabel);
        speedSliderRect = new RectF(x, sy + 8f, x + w, sy + 36f);
        drawSlider(c, speedSliderRect, (speedMult - 1f) / 2f);
    }

    // Tag mỗi toggle với RectF để detect touch
    private List<ToggleHit> toggleHits = new ArrayList<>();

    private boolean drawToggle(Canvas c, float x, float y, float w,
                                String label, boolean val) {
        RectF rect = new RectF(x, y, x + w, y + 54f);
        pToggleBg.setColor(val
            ? Color.argb(220, 200, 70, 0)
            : Color.argb(180, 45, 45, 45));
        c.drawRoundRect(rect, 12f, 12f, pToggleBg);

        pToggleText.setColor(Color.WHITE);
        pToggleText.setTextSize(28f);
        c.drawText(label, x + 18f, y + 36f, pToggleText);

        pToggleText.setColor(val
            ? Color.argb(255, 255, 200, 100)
            : Color.argb(180, 140, 140, 140));
        pToggleText.setTextAlign(Paint.Align.RIGHT);
        c.drawText(val ? "BẬT" : "TẮT", x + w - 16f, y + 36f, pToggleText);
        pToggleText.setTextAlign(Paint.Align.LEFT);

        // Lưu vào hit list
        toggleHits.add(new ToggleHit(rect, label, val));
        return val;
    }

    private void drawSlider(Canvas c, RectF r, float ratio) {
        c.drawRoundRect(r, 8f, 8f, pSliderBg);
        RectF fill = new RectF(r.left, r.top, r.left + r.width() * ratio, r.bottom);
        c.drawRoundRect(fill, 8f, 8f, pSliderFill);
        float knobX = r.left + r.width() * ratio;
        c.drawCircle(knobX, r.centerY(), 18f, pSliderFill);
    }

    // ── TOUCH ─────────────────────────────────────────────────────────────
    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (!menuOpen) return false;

        float tx = e.getX(), ty = e.getY();

        if (e.getAction() == MotionEvent.ACTION_DOWN) {
            // Close
            if (closeRect != null && closeRect.contains(tx, ty)) {
                menuOpen = false; invalidate(); return true;
            }
            // Tabs
            for (int i = 0; i < TABS.length; i++) {
                if (tabRects[i] != null && tabRects[i].contains(tx, ty)) {
                    activeTab = i; invalidate(); return true;
                }
            }
            // Toggles
            toggleHits.clear();
            invalidate(); // redraw để lấy fresh hit list
            for (ToggleHit h : toggleHits) {
                if (h.rect.contains(tx, ty)) {
                    applyToggle(h.label); invalidate(); return true;
                }
            }
            // Slider aim
            if (aimSliderRect != null && activeTab == 1
                    && aimSliderRect.contains(tx, ty)) {
                aimSmooth = (tx - aimSliderRect.left) / aimSliderRect.width();
                aimSmooth = Math.max(0f, Math.min(1f, aimSmooth));
                draggingAim = true; invalidate(); return true;
            }
            // Slider speed
            if (speedSliderRect != null && activeTab == 2
                    && speedSliderRect.contains(tx, ty)) {
                float r = (tx - speedSliderRect.left) / speedSliderRect.width();
                speedMult = 1f + r * 2f;
                speedMult = Math.max(1f, Math.min(3f, speedMult));
                draggingSpeed = true; invalidate(); return true;
            }
        }

        if (e.getAction() == MotionEvent.ACTION_MOVE) {
            if (draggingAim && aimSliderRect != null) {
                aimSmooth = (tx - aimSliderRect.left) / aimSliderRect.width();
                aimSmooth = Math.max(0f, Math.min(1f, aimSmooth));
                invalidate(); return true;
            }
            if (draggingSpeed && speedSliderRect != null) {
                float r = (tx - speedSliderRect.left) / speedSliderRect.width();
                speedMult = 1f + r * 2f;
                speedMult = Math.max(1f, Math.min(3f, speedMult));
                invalidate(); return true;
            }
        }

        if (e.getAction() == MotionEvent.ACTION_UP) {
            draggingAim = draggingSpeed = false;
        }

        return menuRect != null && menuRect.contains(tx, ty);
    }

    private void applyToggle(String label) {
        switch (label) {
            case "Bật ESP":          espEnable   = !espEnable;   break;
            case "Box vuông":        espBox      = !espBox;      break;
            case "Tên player":       espName     = !espName;     break;
            case "Thanh HP":         espHealth   = !espHealth;   break;
            case "Khoảng cách":      espDistance = !espDistance; break;
            case "Mũi tên hướng":    espArrow    = !espArrow;    break;
            case "Bật Aim Assist":   aimEnable   = !aimEnable;   break;
            case "Anti Band":        antiBand    = !antiBand;    break;
            case "Speed Hack":       speedEnable = !speedEnable; break;
        }
    }

    // ── HELPER CLASSES ────────────────────────────────────────────────────
    static class EspEntity {
        String name; float screenX, screenY, boxW, boxH;
        float hp; float distance; float angle; boolean visible;
        EspEntity(String n, float sx, float sy, float bw, float bh,
                  float hp, float dist, float ang) {
            name=n; screenX=sx; screenY=sy; boxW=bw; boxH=bh;
            this.hp=hp; distance=dist; angle=ang; visible=true;
        }
    }

    static class ToggleHit {
        RectF rect; String label; boolean val;
        ToggleHit(RectF r, String l, boolean v) { rect=r; label=l; val=v; }
    }
}
