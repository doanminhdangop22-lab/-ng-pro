package com.dangpro;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    private static final int REQ_OVERLAY = 1001;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView tvStatus = findViewById(R.id.tvStatus);
        Button btnStart   = findViewById(R.id.btnStart);
        Button btnStop    = findViewById(R.id.btnStop);

        btnStart.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                // Xin quyền overlay
                Intent intent = new Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
                startActivityForResult(intent, REQ_OVERLAY);
            } else {
                startOverlay();
                tvStatus.setText("✅ Đang chạy — mở FF rồi double tap vào nút tròn");
            }
        });

        btnStop.setOnClickListener(v -> {
            stopService(new Intent(this, OverlayService.class));
            tvStatus.setText("⏹ Đã dừng");
        });
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_OVERLAY) {
            if (Settings.canDrawOverlays(this)) {
                startOverlay();
                TextView tvStatus = findViewById(R.id.tvStatus);
                tvStatus.setText("✅ Đang chạy — mở FF rồi double tap nút tròn");
            } else {
                Toast.makeText(this, "Cần cấp quyền hiển thị đè!", Toast.LENGTH_LONG).show();
            }
        }
    }

    private void startOverlay() {
        Intent svc = new Intent(this, OverlayService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            startForegroundService(svc);
        else
            startService(svc);
    }
}
