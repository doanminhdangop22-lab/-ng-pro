# Giữ service classes để Android có thể bind
-keep class com.dangpro.OverlayService { *; }
-keep class com.dangpro.GameAccessibilityService { *; }
-keep class com.dangpro.MainActivity { *; }

# Obfuscate hết phần còn lại
-renamesourcefileattribute SourceFile
-keepattributes SourceFile,LineNumberTable

# Xóa log để tránh detect
-assumenosideeffects class android.util.Log {
    public static int d(...);
    public static int v(...);
    public static int i(...);
    public static int w(...);
    public static int e(...);
}
